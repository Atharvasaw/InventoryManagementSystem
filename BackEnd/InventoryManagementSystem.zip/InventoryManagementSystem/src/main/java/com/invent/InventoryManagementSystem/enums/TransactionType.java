package com.invent.InventoryManagementSystem.enums;

public enum TransactionType {
	
	PURCHASE, SALE, RETURN_TO_SUPPLIER
}
