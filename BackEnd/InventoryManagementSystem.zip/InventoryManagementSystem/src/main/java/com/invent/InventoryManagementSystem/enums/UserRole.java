package com.invent.InventoryManagementSystem.enums;

public enum UserRole {
	
	 ADMIN, MANAGER
}
