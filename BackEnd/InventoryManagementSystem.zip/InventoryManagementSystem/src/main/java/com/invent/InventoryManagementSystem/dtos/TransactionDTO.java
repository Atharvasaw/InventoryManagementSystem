package com.invent.InventoryManagementSystem.dtos;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.invent.InventoryManagementSystem.enums.TransactionStatus;
import com.invent.InventoryManagementSystem.enums.TransactionType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionDTO {
	
	 	private Long id;

	    private Integer totalProducts;

	    private BigDecimal totalPrice;


	    private TransactionType transactionType; // pruchase, sale, return


	    private TransactionStatus status; //pending, completed, processing

	    private String description;
	    private String note;

	    private LocalDateTime createdAt;
	    private LocalDateTime updateAt;

	    private ProductDTO product;

	    private UserDTO user;

	    private SupplierDTO supplier;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Integer getTotalProducts() {
			return totalProducts;
		}

		public void setTotalProducts(Integer totalProducts) {
			this.totalProducts = totalProducts;
		}

		public BigDecimal getTotalPrice() {
			return totalPrice;
		}

		public void setTotalPrice(BigDecimal totalPrice) {
			this.totalPrice = totalPrice;
		}

		public TransactionType getTransactionType() {
			return transactionType;
		}

		public void setTransactionType(TransactionType transactionType) {
			this.transactionType = transactionType;
		}

		public TransactionStatus getStatus() {
			return status;
		}

		public void setStatus(TransactionStatus status) {
			this.status = status;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getNote() {
			return note;
		}

		public void setNote(String note) {
			this.note = note;
		}

		public LocalDateTime getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}

		public LocalDateTime getUpdateAt() {
			return updateAt;
		}

		public void setUpdateAt(LocalDateTime updateAt) {
			this.updateAt = updateAt;
		}

		public ProductDTO getProduct() {
			return product;
		}

		public void setProduct(ProductDTO product) {
			this.product = product;
		}

		public UserDTO getUser() {
			return user;
		}

		public void setUser(UserDTO user) {
			this.user = user;
		}

		public SupplierDTO getSupplier() {
			return supplier;
		}

		public void setSupplier(SupplierDTO supplier) {
			this.supplier = supplier;
		}
	    
	    

}
