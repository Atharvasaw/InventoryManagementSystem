package com.invent.InventoryManagementSystem.enums;

public enum TransactionStatus {

	PENDING, PROCESSING, COMPLETED, CANCELLED
}
